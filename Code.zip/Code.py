# PROCESSING


from pyspark import SparkContext
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import *

spark = SparkSession.builder.getOrCreate()
sc = SparkContext.getOrCreate()
#Q1 
#  (a).How is the data structured?  

#[aka@canterbury.ac.nz@mathmadslinux1p ~]$ hdfs dfs -ls /data/ghcnd

#Draw a directory tree to represent this in a sensible way?.

#hdfs dfs -ls -R /data/ghcnd | awk '{print $8}' | sed -e 's/[^-][^\/]*\//--/g' -e 's/^/ /' -e 's/-/|/'


# (b). How many years are contained in daily ?

#[aka233@canterbury.ac.nz@mathmadslinux1p ~]$ hdfs dfs -ls /data/ghcnd/daily | wc -l 

#how does the size of the data change?

#aka233@canterbury.ac.nz@mathmadslinux1p ~]$ hdfs dfs -ls -h /data/ghcnd/daily

# (c).What is the total size of all of the data? #How much of that is daily?

[aka233@canterbury.ac.nz@mathmadslinux1p ~]$ hdfs dfs -du -s /data/ghcnd


# Question 2 
# (a)Define schemas for each of daily, stations, states, countries, and inventory based
#    on the descriptions in this assignment and the GHCN Daily README. These should use
#    the data types defined in pyspark.sql. 
# and
# c)  Load each of stations, states, countries, and inventory into Spark as well. You will
#      need to find a way to parse the fixed width text formatting, as this format is not included in
#      the standard spark.read library. You could try using spark.read.format and
#      pyspark.sql.functions.substring or finding an existing open source library.
#      How many rows are in each metadata table? How many stations do not have a WMO ID? 

schema_daily = StructType([
    StructField('ID', StringType()),
    StructField('DATE', DateType()),
    StructField('ELEMENT', StringType()),
    StructField('VALUE', IntegerType()),
    StructField('MEASUREMENT FLAG', StringType()),
    StructField('QUALITY FLAG', StringType()),
    StructField('SOURCE FLAG', StringType()),
    StructField('OBSERVATION TIME', StringType()),
])

countries_text_only = (
    spark.read.format("text")
    .load("hdfs:///data/ghcnd/countries")
    )
countries_text_only.show(5,False)

states_text_only = (
    spark.read.format("text")
    .load("hdfs:///data/ghcnd/states")
    )
states_text_only.show(5, False)


inventory_text_only = (
    spark.read.format("text")
    .load("hdfs:///data/ghcnd/inventory")
    )
inventory_text_only.show(5, False)


stations_text_only = (
    spark.read.format("text")
    .load("hdfs:///data/ghcnd/stations")
)
stations_text_only.show(5, False)

stations = stations_text_only.select(
    F.trim(F.substring(F.col('value'), 1, 11)).alias('ID').cast(StringType()),
    F.trim(F.substring(F.col('value'),13,8)).alias('LATITUDE').cast(FloatType()),
    F.trim(F.substring(F.col('value'),22,9)).alias('LONGITUDE').cast(FloatType()),
    F.trim(F.substring(F.col('value'),32,6)).alias('ELEVATION').cast(FloatType()),
    F.trim(F.substring(F.col('value'), 39, 2)).alias('STATE').cast(StringType()),
    F.trim(F.substring(F.col('value'), 42, 30)).alias('NAME').cast(StringType()),
    F.trim(F.substring(F.col('value'), 73, 3)).alias('GSN FLAG').cast(StringType()),                                                                
    F.trim(F.substring(F.col('value'), 77, 3)).alias('HCN/CRN FLAG').cast(StringType()),
    F.trim(F.substring(F.col('value'), 81, 5)).alias('WMO ID').cast(StringType()))                                                                       

stations.show(5, False)

countries = countries_text_only.select(
    F.trim(F.substring(F.col('value'),1,2)).alias("code").cast(StringType()),
    F.trim(F.substring(F.col('value'),4,50-4+1)).alias("NAME").cast(StringType())
    )
countries.show(5,False)


states = states_text_only.select(
    F.trim(F.substring(F.col('value'),1,2)).alias('CODE').cast(StringType()),
    F.trim(F.substring(F.col('value'),4,50-4+1)).alias('NAME').cast(StringType())
    )
states.show(5,False)


inventory = inventory_text_only.select(
    F.trim(F.substring(F.col('value'),1,11)).alias('ID').cast(StringType()),
    F.trim(F.substring(F.col('value'),13,8)).alias('LATITUDE').cast(FloatType()),
    F.trim(F.substring(F.col('value'),22,9)).alias('LONGITUDE').cast(FloatType()),
    F.trim(F.substring(F.col('value'),32,4)).alias('ELEMENT'). cast(StringType()),
    F.trim(F.substring(F.col('value'),37,4)).alias('FIRSTYEAR').cast(IntegerType()),
    F.trim(F.substring(F.col('value'),42,4)).alias('LASTYEAR').cast(IntegerType())
    )
inventory.show(5, False)





# b)  Load 1000 rows of hdfs:///data/ghcnd/daily/2020.csv.gz into Spark using the limit
#     command immediately after the read command.
#     Was the description of the data accurate? Was there anything unexpected? 

daily = (
    spark.read.format("com.databricks.spark.csv")
    .option("header", "false")
    .option("inferSchema", "false")
    .option("dateFormat", "yyyyMMdd")
    .schema(schema_daily)
    .load("hdfs:///data/ghcnd/daily/2020.csv.gz")
    .limit(1000)
)
daily.cache()
daily.show(5, False)


#How many rows are in each metadata table?

stations_count = stations.count()
stations_count

countries_count = countries.count()
countries_count


states_count = states.count()
states_count

inventory_count = inventory.count()
inventory_count


#   How many stations do not have a WMO ID?
stations.filter(stations['WMO ID'] == "").count()

#Question 3 
#   (a)Extract the two character country code from each station code in stations and store the
#       output as a new column using the withColumn command.

stations_having_code = stations.withColumn("CODE" , stations.ID.substr(1,2))
stations_having_code.show()

#  (b)LEFT JOIN stations with countries using your output from part (a).

stations_left_countries = stations_having_code.join(countries, on='CODE', how = 'left')
stations_left_countries.show()


# (c) LEFT JOIN stations and states, allowing for the fact that state codes are only provided
#    for stations in the US.

stations_left_states = stations_having_code.join(states, on ='CODE', how = 'left')
stations_left_states.show()

# (d) Based on inventory, what was the first and last year that each station was active and
#     collected any element at all?
#     How many different elements has each station collected overall?
#     Further, count separately the number of core elements and the number of ”other” elements
#     that each station has collected overall.
#     How many stations collect all five core elements? How many only collected precipitation?


inventory_Year_Active = (
    inventory
	.where(F.col('ELEMENT') ! = "")
    .groupBy('ID')
    .agg(F.min(inventory['FIRSTYEAR']).alias('First_Year_Active'),
        F.max(inventory['LASTYEAR']).alias('Last_Year_Active')
        )
    .orderBy('ID')
    )

    

#    How many different elements has each station collected overall?


UniqueElements = inventory.groupBy('ID').agg(F.countDistinct('ELEMENT').alias('Unique_Element_Count')).show()
UniquecountElements.show()

#   Further, count separately the number of core elements and the number of ”other” elements
#   that each station has collected overall.

criteria = lambda cond: F.sum(F.when(cond,1).otherwise(0))

number_of_core_elements = inventory.groupBy('ID').agg(
    criteria((F.col('ELEMENT').isin('PRCP', 'SNOW', 'SNWD', 'TMAX', 'TMIN'))))
number_of_core_elements.show()


number_of_other_elements = inventory.groupBy('ID').agg(
    criteria((F.col('ELEMENT') != 'PRCP') & (F.col('ELEMENT') != 'SNOW') & (F.col('ELEMENT') != 'SNWD') & (F.col('ELEMENT') != 'TMAX') & (F.col('ELEMENT') != 'TMIN')).alias('OtherElementsCount'))

number_of_other_elements.show()


#  How many stations collect all five core elements? 

station_with_all_five_core_elements = (
    inventory
    .select(inventory['ID'])
    .filter(inventory['ELEMENT'].isin('PRCP', 'SNOW', 'SNWD', 'TMAX', 'TMIN')).groupBy('ID').count()
    .orderBy('ID')
    )

station_with_all_five_core_elements.show()


#  How many only collected precipitation?
stations_collected_only_precipitation = (
    inventory
    .select(inventory['ID'])
    .filter(inventory['ELEMENT']=='PRCP').groupBy('ID').count()
    .orderBy('ID')
    )

stations_collected_only_precipitation.show()

#   Note that we could also determine the set of elements that each station has collected and
#   store this output as a new column using pyspark.sql.functions.collect set but it will
#    be more efficient to first filter inventory by element type using the element column and
#   then to join against that output as necessary.

Bit1 = inventory_Year_Active.join(UniquecountElements, on ='ID', how = 'inner')
Bit1.show()

Bit2 = Bit1.join(number_of_core_elements, on = 'ID', how = 'inner')
Bit2.show()

Bit3 = Bit2.join(number_of_other_elements, on = 'ID', how = 'inner')
Bit3.show()

inventory_filter_by_element = Bit3.join(stations_collected_only_precipitation, on = 'ID', how = 'inner')
inventory_filter_by_element.show()


# (e)
enriched_stations = stations_having_code.join(inventory_filter_by_element, on = 'ID', how = 'left')
enriched_stations.show()

enriched_stations.write.mode("overwrite").csv("hdfs:///user/aka233/outputs/ghcnd/enriched_stations.csv")

# (f)

daily_left_enriched = daily.join(enriched_stations, on = 'ID', how = 'left')
daily_left_enriched.show()



# ANALYSIS



# Question 1

#    (a)  How many stations are there in total? How many stations were active in 2000?



activestations_2000 = (
    enriched_stations
    .select(enriched_stations.ID)
    .filter((enriched_stations['First_Year_Active'] >= 2000) & (enriched_stations['Last_Year_Active'] <= 2000 )).count()
    )

activestations_2000

enriched_stations.filter(enriched_stations['GSN FLAG'] != '').count()

HCN_flag = enriched_stations.filter(enriched_stations['HCN/CRN FLAG'] = 'HCN').count() 
CRN_flag = enriched_stations.filter(enriched_stations['HCN/CRN FLAG'] = 'HCN').count()

HCN_CRN_sum = HCN_flag + CRN_flag
HCN_CRN_sum


# (b)  Count the total number of stations in each country, and store the output in countries using
#      the withColumnRenamed command.

COUNTCODE = (enriched_stations
        .groupBy("CODE")
        .count()
        .select(
            F.col("CODE"),
            F.col("count").alias("Station_code_count")
            )
         )

COUNTCODE.show()

countries = countries.join(COUNTCODE, on ='CODE', how = 'left').withColumnRenamed("Station_code_count", "CODECOUNT")
countries.write.mode("overwrite").csv("hdfs:///user/aka233/outputs/ghcnd/countries.csv")

states = states.join(COUNTCODE, on ='CODE', how = 'left').withColumnRenamed("Station_code_count", "CODECOUNT")
states.write.mode("overwrite").csv("hdfs:///user/aka233/outputs/ghcnd/states.csv")

#    (c)How many stations are there in the Southern Hemisphere only?

enriched_stations.filter(enriched_stations['Latitude'] < 0).count()




countries.filter((countries.NAME != 'United States') & (countries.NAME.like('%United States%'))).agg(F.sum(countries['CODECOUNT'])).show()



# Question 2

# (a)  Write a Spark function that computes the geographical distance between two stations using
#      their latitude and longitude as arguments. You can test this function by using CROSS JOIN
#      on a small subset of stations to generate a table with two stations in each row.

from math import radians, cos, sin, asin, sqrt


def geographic_distance(longitute_first, latitude_first, longitute_second, latitude_second):

    
    longitute_first, latitude_first, longitute_second, latitude_second = map(radians, [longitute_first,  latitude_first, longitute_second, latitude_second])
    distance_longitute = longitute_second - longitute_first
    distance_latitude = latitude_second - latitude_first
    
    area = sin(distance_latitude/2)**2 + cos(latitude_first) * cos(latitude_second) * sin(distance_longitute/2)**2
    
    central_angle = 2 * asin(sqrt(area))
    radius = 6371
   
    distance = central_angle * radius
    return abs(round(distance, 2))

geographic_distance_udf = F.udf(geographic_distance)

small_check_on_stations = (
    enriched_stations
    .select("ID","LATITUDE","LONGITUDE")
    .limit(50)
    )

small_check_on_stations_join = (small_check_on_stations.crossJoin(small_check_on_stations).toDF(
    "ID_A", "LATITUDE_A", "LONGITUDE_A", "ID_B", "LATITUDE_B", "LONGITUDE_B"))

small_check_on_stations_join = (small_check_on_stations_join.filter(
    small_check_on_stations_join['ID_A'] != small_check_on_stations_join['ID_B'])
    )

small_check_on_stations_distance = (
    small_check_on_stations_join.withColumn("Distance", geographic_distance_udf(small_check_on_stations_join['LATITUDE_A'], small_check_on_stations_join['LONGITUDE_A'],
                                                                     small_check_on_stations_join['LATITUDE_B'], small_check_on_stations_join['LONGITUDE_B']).cast(DoubleType()))
    )

small_check_on_stations_distance.show()



new_zealand_stations = (
    enriched_stations
    .filter(enriched_stations['CODE'] == 'NZ').alias("New_Zealand")
    .select("ID","LATITUDE","LONGITUDE")
    )

new_zealand_stations_join = (new_zealand_stations.crossJoin(new_zealand_stations).toDF(
    "ID_A", "LATITUDE_A", "LONGITUDE_A", "ID_B", "LATITUDE_B", "LONGITUDE_B"))

new_zealand_stations_join = (new_zealand_stations_join.filter(
    new_zealand_stations_join['ID_A'] != new_zealand_stations_join['ID_B'])
    )

new_zealand_stations_distance = (
    new_zealand_stations_join.withColumn("Distance", geographic_distance_udf(new_zealand_stations_join['LATITUDE_A'], new_zealand_stations_join['LONGITUDE_A'],
                                                                 new_zealand_stations_join['LATITUDE_B'], new_zealand_stations_join['LONGITUDE_B']).cast(DoubleType()))
    )

new_zealand_stations_distance.show()


# Question 3
#     a) Based on these results, is it possible for Spark to load and apply transformations in parallel
#       or the year 2020? What about the year 2010?

hdfs fsck /data/ghcnd/daily/2020.csv.gz -files -blocks

hdfs fsck /data/ghcnd/daily/2010.csv.gz -files -blocks
#     b) Load and count the number of observations in daily for each of the years 2015 and 2020.
#       How many tasks were executed by each stage of each job?
#       You can check this by using your application console. which you can find in the web
#       user interface (mathmadslinux1p:8080). You can either determine the number of tasks
#       executed by each stage of each job or determine the total number of tasks completed by
#       each executor after the job has completed.
#       Did the number of tasks executed correspond to the number of blocks in each input?
daily_year_2015 = (
    spark.read.format("com.databricks.spark.csv")
    .option("header", "false")
    .option("inferSchema", "false")
    .option("dateFormat", "yyyyMMdd")
    .schema(schema_daily)
    .load("hdfs:///data/ghcnd/daily/2015.csv.gz")
)

daily_year_2015.count()

daily_year_2020 = (
    spark.read.format("com.databricks.spark.csv")
    .option("header", "false")
    .option("inferSchema", "false")
    .option("dateFormat", "yyyyMMdd")
    .schema(schema_daily)
    .load("hdfs:///data/ghcnd/daily/2020.csv.gz")
)

daily_year_2020.count()

#       c) and d)
                       
daily_year_2015_2020 = (
    spark.read.format("com.databricks.spark.csv")
    .option("header", "false")
    .option("inferSchema", "false")
    .option("dateFormat", "yyyyMMdd")
    .schema(schema_daily)
    .load("hdfs:///data/ghcnd/daily/20{15,16,17,18,19,20}.csv.gz")
)

daily_year_2015_2020.count()

# Question 4
#    a) Count the number of rows in daily.

daily_rows = (
    spark.read.format("com.databricks.spark.csv")
    .option("header", "false")
    .option("inferSchema", "false")
    .option("dateFormat", "yyyyMMdd")
    .schema(schema_daily)
    .load("hdfs:///data/ghcnd/daily/*.csv.gz")
)

daily_rows.count()

#   b)How many observations are there for each of the five core elements?
#     Which element has the most observations?

daily_core_elements = (
    daily_rows
    .filter(daily_rows['ELEMENT'].isin('PRCP', 'SNOW', 'SNWD', 'TMAX', 'TMIN'))
    )

daily_core_elements_count = (
    daily_rows
    .select(daily_rows['ELEMENT'])
    .groupBy('ELEMENT')
    .count()
    )

daily_core_elements_count.show()

# (c) Many stations collect TMAX and TMIN, but do not necessarily report them simultaneously
#     due to issues with data collection or coverage. Determine how many observations of TMIN
#     do not have a corresponding observation of TMAX.
#     How many different stations contributed to these observations?
daily_TMAX_TMIN_data = (
    daily_rows
    .filter(F.col("ELEMENT").isin(["TMIN", "TMAX"]))
    .groupBy("ID", "DATE")
    .agg(
        F.collect_set(F.col("ELEMENT")).alias("SET")
    )
    .select(
        F.col('ID'),
        F.col('DATE'),
        F.col('SET'),
        F.when(
            F.array_contains(F.col("SET"), "TMIN") & (F.size(F.col("SET")) == 1),
            1
        ).otherwise(0).alias('ONLY_TMIN')
    )

)

daily_TMAX_TMIN_data.show(4, False)

daily_TMAX_TMIN_data.filter(F.col("ONLY_TMIN") == 1).count()

##

daily_t_code = daily_t.withColumn('CODE', F.substring('ID', 1, 2))
daily_t_nz_year = daily_t_code.filter(F.col('CODE') == 'NZ').withColumn('YEAR', F.substring('DATE',1,4))




# Year Count
nz_t = daily_t_nz_year.agg(F.countDistinct(F.col('YEAR')).alias('YearCount'))
nz_t.show()

daily_t_nz_year.filter(F.col("ONLY_TMIN") == 1).count()

daily_t_nz_year_concat = daily_t_nz_year.withColumn("SET_t", F.concat_ws(",",F.col("SET")))
daily_t_nz_year_concat = daily_t_nz_year.drop('SET')

daily_t_nz_year_concat.write.mode("overwrite").csv("hdfs:///user/aka233/outputs/ghcnd/daily_t_nz_year_concat.csv")


# (e)

daily_code = daily_rows.withColumn("CODE", daily_rows.ID.substr(1,2))
daily_code_with_year = daily_code.withColumn('YEAR', daily_rows.DATE.substr(1,4))


 

# join with country table to get the country name

daily_year_countryname = daily_code_with_year.join(countries, on = 'CODE', how = 'left')

 

# filter the preciptation records and group by year and country

avg_rain = (
    daily_year_countryname
    .filter(F.col('ELEMENT') == 'PRCP')
    .groupBy('NAME')
    .agg(
            F.avg('VALUE').alias('AVERAGERAINFALL'))
        .orderBy('NAME')
        .select(
            F.col('NAME'),
            F.col('AVERAGERAINFALL')

        )
        )
					




avg_rain.write.mode("overwrite").csv("hdfs:///user/aka233/outputs/ghcnd/avg_rain.csv")


average_rainfall_max = average_rainfall.agg({"Average_Rainfall": "max"}).collect()


#av_max = average_rainfall.orderBy(F.col('Average_Rainfall'), ascending = False).take(2)

